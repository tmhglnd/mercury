Apple modelled with Amapi
Textures made with Painter 3D
4400 polygons
(I know, it's a lot)

---------------------------------

Pomme mod�lis�e avec Amapi
Textures faites avec Painter 3D
4400 polygones
(Je sais, c'est beaucoup)


=================================
From The Virtual lands Meshbank

http://o.ffrench.free.fr/meshbank
=================================