Mushrooms modelled with Amapi	

10 objects

10560 polygons

UV mapping coordinates and simple texture



---------------------------------



Champignons mod�lis�s avec Amapi

10 objets

10560 polygones

Cordonn�es de mapping UV et texture simple



=================================

From The Virtual lands Meshbank



http://o.ffrench.free.fr/meshbank

=================================